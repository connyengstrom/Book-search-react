import React from 'react';
import DetailedView from './../components/DetailedView.jsx';
import ListView from './../components/ListView.jsx';

/* Detta objekt bestämmer vilken vy som ska visas och renderar vyn. 
Tar emot arrayn med sökresultat. detailedView är en state som bestämmer
vilken vy som ska visas. amountFound är en variabel med hur många böcker
som hittades. Returnerar funktionen goToDetails med bokens "nyckel" som argument till föräldern, denna funktion
körs när användaren har klickat på knappen för mer information om en bok. */
const View = ({ searchResult, detailedView, amountFound, goToDetails }) => {
  //Om list-vy ska visas.
  if (detailedView[0] == false) {
    /* Objekt för list-vyn. När goToDetails körs ska vyn ändras till detalj-vy. Skicka vidare funktionen till föräldern (App) med argumenten 'true' och bokens plats i arrayn */
    return (
      <ListView
        listBooks={searchResult}
        goToDetails={(i) => goToDetails([true, i])}
        amountFound={amountFound}
      />
    );
  } else {
    //Om detalj-vy ska visas.
    /* Objekt för detalj-vyn. När goToDetails körs ska vyn ändras till list-vy. Skicka vidare funktionen till föräldern (App). */
    return (
      <DetailedView
        book={searchResult[detailedView[1]]}
        goToDetails={() => goToDetails([false, 0])}
      />
    );
  }
};

export default View;
