import React from 'react';

/* Komponent för att visa hur många sökresultat som hittades.
Komponenten är inte så nödvändig då samma sak kan skrivas ut med en rad kod i föräldern,
men gör koden mer organiserad. */
const DisplayAmount = ({ amount, phraseBefore, phraseAfter }) => {
  //Visa bara resultatet om vi har i alla fall en träff.
  if (amount > 0) {
    return (
      <p>
        {phraseBefore} {amount} {phraseAfter}
      </p>
    );
  }
};

export default DisplayAmount;
