import React from 'react';

/* Komponent för en input-fält. newSearchPhrase körs när inmatningen ändras och värdet skickas
tillbaka till föräldern.
Komponenten är inte så nödvändig då samma sak kan skrivas ut med en rad kod i föräldern,
men gör koden mer organiserad. 
'ph' används som placeholder i input-fältet */
const StandardInputField = ({ ph, newSearchPhrase }) => {
  return (
    <input
      type="text"
      placeholder={ph}
      onChange={(e) => newSearchPhrase(e.target.value)}
    ></input>
  );
};

export default StandardInputField;
