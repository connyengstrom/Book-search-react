import React from 'react';
import ConcatenateArrayWithTitle from './ConcatenateArrayWithTitle.jsx';

/* Komponent för att visa mer detaljer om en bok.
Tar emot boken som objekt. Funktionen goToDetails körs när användaren klickar
på gå tillbaka. */
const DetailedView = ({ book, goToDetails }) => {
  //Deklarera variabel för URL till bokomslag
  let coverUrl;
  //Om boken har ett ISBN-nummer, skapa URL som textsträng, annars skapa tom sträng
  book.isbn != undefined
    ? (coverUrl =
        'https://covers.openlibrary.org/b/isbn/' + book.isbn[0] + '-M.jpg')
    : (coverUrl = '');

  return (
    <>
      {/*Knapp för att gå tillbaka till list-vy,
      skickar tillbaka funktionen goToDetails till komponenten "View"*/}
      <button onClick={() => goToDetails()}>Tillbaka</button>

      {/*Skriv ut bokens titel*/}
      <p>
        <span className="bold">Titel: </span>
        {book.title}
      </p>

      {/*Skriv ut bokens alla författare, förlag, språk och ämnen för boken*/}
      <ConcatenateArrayWithTitle
        title="Författare:"
        arr={book.author_name}
        delimiter=", "
      />
      <ConcatenateArrayWithTitle
        title="Förlag:"
        arr={book.publisher}
        delimiter=", "
      />
      <ConcatenateArrayWithTitle
        title="Språk:"
        arr={book.language}
        delimiter=", "
      />
      <ConcatenateArrayWithTitle
        title="Ämnen:"
        arr={book.subject}
        delimiter=", "
      />

      {/*Visa omslagsbild för boken.
      Alla böcker har inte ISBN eller bild, då skrivs ett tomt element ut.*/}
      <img src={coverUrl}></img>
    </>
  );
};

export default DetailedView;
