import React from 'react';
import DisplayAmount from './DisplayAmount.jsx';

/* Komponent för att visa list-vyn, en tabell med alla böcker.
Tar emot en array med alla böcker som ska skrivas ut och antalet funna böcker.
Returnerar goToDetails när knappen om mer information blir klickad.
Vyn byts sedan i föräldern (App) */
const ListView = ({ listBooks, amountFound, goToDetails }) => {
  //Rendera bara tabellen om vi har minst ett sökresultat
  if (listBooks.length > 0) {
    return (
      <div className="listViewWrapper">
        {/*Komponent för att visa hur många sökresultat som hittades*/}
        <DisplayAmount
          amount={amountFound}
          phraseBefore="Hittade: "
          phraseAfter="böcker på din sökning"
        />

        {/*Tabellen med böcker. Skapa rad för rubriker */}
        <table className="table">
          <tr className="bold">
            <td>Titel</td>
            <td>Författare</td>
            <td>Första utgivningsår</td>
          </tr>

          {/*Loopa nu igenom bok-arrayn och skapa en rad per bok*/}
          {listBooks.map((data, i) => (
            <tr key={i}>
              <td className="bold">{data.title}</td>
              <td>{data.author_name[0]}</td>
              <td>{data.first_publish_year}</td>
              {/*Knapp för att gå till detaljerad vy för denna bok.
              Returnerar goToDetails med 'i' som argument, vilket är bokens plats i arrayn för alla sökresultat. Vi kan därmed i föräldern veta vilken bok som vi ska visa
              detaljerad vy för när funktionen returnerar.*/}
              <button onClick={() => goToDetails(i)}>Mer information</button>
            </tr>
          ))}
        </table>
      </div>
    );
  }
};

export default ListView;
