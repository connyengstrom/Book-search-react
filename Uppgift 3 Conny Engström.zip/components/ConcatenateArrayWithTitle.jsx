import React from 'react';

/* Komponent som tar en titel, en array och en avgränsare.
Formaterar detta till en sträng med titel och alla 
array-värden separerade med vald avgränsare.
 */
const ConcatenateArrayWithTitle = ({ title, arr, delimiter }) => {
  return (
    <p>
      <span className="bold">{title} </span>
      {arr != undefined ? arr.join(delimiter) : '-'}
    </p>
  );
};

export default ConcatenateArrayWithTitle;
