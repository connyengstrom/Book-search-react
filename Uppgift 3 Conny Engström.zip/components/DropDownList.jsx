import React from 'react';

/* Komponent för att skapa en drop-down-lista.
Tar emot en array med objekt för listan. Objekten ska ha nycklarna 'value' och 'text'.
setSearchType är en funktion som returnerar det valda värdet till föräldern.
 */
const DropDownList = ({ selections, setSearchType }) => {
  return (
    <select onChange={(e) => setSearchType(e.target.value)}>
      {selections.map((data) => (
        <option value={data.value}>{data.text}</option>
      ))}
    </select>
  );
};

export default DropDownList;
