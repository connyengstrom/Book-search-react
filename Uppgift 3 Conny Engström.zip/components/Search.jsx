import React from 'react';
import StandardInputField from './../components/StandardInputField.jsx';
import DropDownList from './../components/DropDownList.jsx';

/* Komponent som fungerar som wrapper för allt som har med sökfunktionen att göra.
Returnerar sökfras, typen som användaren har valt och klick på knappen till föräldern. */
const Search = ( {newSearchPhrase, setSearchType, clicked} ) => {

  //En array med objekt för de val som vi vill ha med i drop-down-listan
  const dropDownListSelections = [
    {value : "title", text : "Titel"},
    {value : "author", text : "Författare"},
    {value : "subject", text : "Ämne"}
  ]
  
  return (
    <div className="searchWrapper">
      {/* Komponent för text-fält */}
      <StandardInputField
        ph="Sök..."
        newSearchPhrase={(e) => {
          newSearchPhrase(e);
        }}
      />

      {/* Komponent för drop-down-lista */}
      <DropDownList selections={dropDownListSelections} setSearchType={(e) => setSearchType(e)} />

      {/* Sök-knapp */}
      <button onClick={() => clicked()}>Sök</button>
    </div>
  )
}

export default Search;