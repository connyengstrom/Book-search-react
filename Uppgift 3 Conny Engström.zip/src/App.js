//Importera React, hooks, css-stilar och komponenter
import React, { useEffect, useState } from 'react';
import './style.css';
import Search from './../components/Search.jsx';
import View from './../components/View.jsx';

export default function App() {
  //// Hooks ////
  //Inmatningen från sökfältet
  const [searchPhrase, setSearchPhrase] = useState('');

  //De första 30 resultaten
  const [searchResult, setSearchResult] = useState([]);

  //Mängden böcker som passar användarens inmatning
  const [amountFound, setAmountFound] = useState(0);

  //Bestämmer vilken vy som används. false = listan, true = detaljerad information.
  //Andra värdet i arrayn är bokens plats i arrayn med sökresult, nödvändigt för detalj-vyn.
  const [detailedView, setDetailedView] = useState([false, 0]);

  //Håller värdet för drop-down-listan, starta med title
  const [searchType, setSearchType] = useState('title');

  //// Funktioner ////
  //Asynkront anrop för att fetcha data från API.
  async function fetchRequest() {
    //Kolla att vi faktiskt har en sträng att söka på så att vi inte skickar onödiga API-anrop
    if (searchPhrase != '') {
      //URI som bestämmer ämne och sökfras. searchType är värdet från drop-down-listan.
      let uri =
        'https://openlibrary.org/search.json?' +
        searchType +
        '=' +
        searchPhrase;
      const response = await fetch(uri);
      const books = await response.json();

      //Returnera JSON-objekt med alla träffar
      return books;
    }
  }

  //Funktion som körs när använadren klickar på sökknappen
  function searchBooks() {
    //Ta bort de gamla sökresultaten och sätt vyn till lista
    setSearchResult([]);
    setAmountFound(0);
    setDetailedView([false, 0]);

    //Kör en ny fetch
    fetchRequest()
      .then((books) => {
        //Spara de första 30 böckerna i searchResult
        setSearchResult(books.docs.slice(0, 30));
        //Spara även antalet böcker som hittades
        setAmountFound(books.numFound);
      })
      //Logga felmeddelanden om vi får några
      .catch((error) => console.log('Error: ', error));
  }

  //// App-komponent ////
  //Rendera alla komponenter och JSX i våran app
  return (
    <div className="mainWrapper">
      <h1>Sök böcker</h1>

      {/*Komponent för sökfunktionen*/}
      <Search
        newSearchPhrase={(i) => setSearchPhrase(i)}
        setSearchType={(e) => setSearchType(e)}
        clicked={() => searchBooks()}
      />

      {/*Komponent för vyerna*/}
      <View
        searchResult={searchResult}
        detailedView={detailedView}
        amountFound={amountFound}
        goToDetails={(i) => setDetailedView(i)}
      />
    </div>
  );
}
